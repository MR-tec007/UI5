sap.ui.define([
	] , function () {
		"use strict";

		return {
			Unit : function (aa) {
				if (aa =="---") {
					return "replaced";
				}else{
					return aa;
				}
			}
		};

	}
);