sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("form.controller.Grid1", {

		onInit: function() {
			// set mock model

			var sPath = jQuery.sap.getResourcePath("form/webapp/products.json");
			var oModel = new JSONModel(sPath);
			this.getView().setModel(oModel);
			var vModel = new JSONModel(jQuery.sap.getResourcePath("form/webapp/Books.json"));
			this.getView().setModel(new JSONModel(vModel));
			this.getView().setModel(vModel);
		
		},
		press : function(evt) {
			MessageToast.show("The GenericTile is pressed.");
		},
			onPressT: function (oEvent) {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("ProductsList");
			}
	});
});