sap.ui.define([
			"sap/ui/core/mvc/Controller",
			"sap/ui/model/json/JSONModel",
			"sap/m/MessageToast",
			"sap/m/ToolbarSpacer",
			"sap/ui/table/Row",
			"sap/ui/thirdparty/jquery"
		], function(Controller, JSONModel, MessageToast, ToolbarSpacer, TableRow, jQuery) {
			"use strict";

			return Controller.extend("form.controller.DragAndDrop", {

					onInit: function() {
						var InputJson = {
							Products: []
						};
						this.products1 = new sap.ui.model.json.JSONModel(InputJson);
						this.getView().setModel(this.products1, "products1");

					},
					onAfterRendering: function() {
						// this.oProductsModel=this.getOwnerComponent().getModel("products");
						var oView = this.getView();
						 var oTable = this.byId("table1");
						// set explored app's demo model on this sample
						this.oProductsModel = this.getOwnerComponent().getModel("products");
						oView.setModel(this.oProductsModel);
						var aColumns = oTable.getColumns();

      // Create a button for the second column (index 1)
      var oButton = new sap.m.Button({
        text: "Dynamic Button",
        press: function(oEvent) {
          // Handle the button press event
        }
      });

      // Use the factory function of the column to add the button to the cells
      //aColumns[2].setTemplate(oButton);
					},

					getSelectedRowContext: function(sTableId, fnCallback) {
						var oTable = this.byId(sTableId);
						var iSelectedIndex = oTable.getSelectedIndex();

						if (iSelectedIndex === -1) {
							MessageToast.show("Please select a row!");
							return;
						}

						var oSelectedContext = oTable.getContextByIndex(iSelectedIndex);
						if (oSelectedContext && fnCallback) {
							fnCallback.call(this, oSelectedContext, iSelectedIndex, oTable);
						}

						return oSelectedContext;
					},

					onDragStart: function(oEvent) {
						var oDraggedRow = oEvent.getParameter("target");
						var oDragSession = oEvent.getParameter("dragSession");

						// keep the dragged row context for the drop action
						oDragSession.setComplexData("draggedRowContext", oDraggedRow.getBindingContext());
					},

					onDropTable1: function(oEvent) {
						var oDragSession = oEvent.getParameter("dragSession");
						var oDraggedRowObjectPath = oDragSession.getDragControl().getBindingContext("products1").getPath();
						var oDraggedRowContext = oDragSession.getDragControl().getBindingContext("products1").getObject(oDraggedRowObjectPath);
						var oPath = oDraggedRowObjectPath.split("/");
						if (!oDraggedRowContext) {
							return;
						}
						var InputJson = this.oProductsModel.getData();
						var oldJson = this.products1.getData();
						oldJson.Products.splice(oPath[2], 1);
						this.products1.setData(oldJson);
						this.products1.refresh(true);
						InputJson.Products.push(oDraggedRowContext);
						this.oProductsModel.setData(InputJson);
					},

					moveToTable1: function() {
						this.getSelectedRowContext("table2", function(oSelectedRowContext, iSelectedRowIndex, oTable2) {
							var oTable1 = this.oProductsModel.getData();
							var RowData1 = {
								Products: []
							};

							var path = oSelectedRowContext.getPath().split("/");
							var oldJson = this.products1.getData();
							
							var RowData = this.products1.getData().Products[path[2]];
							RowData1.Products[0] = RowData;
							for (var i = 0; i < oTable1.Products.length; i++) {
								RowData1.Products.push(oTable1.Products[i]);
							}
							oldJson.Products.splice(path[2], 1);
							this.products1.setData(oldJson);
							this.products1.refresh(true);
							this.oProductsModel.setData(RowData1);
							this.oProductsModel.refresh(true);
						});
					},

					onDropTable2: function(oEvent) {
						var oDragSession = oEvent.getParameter("dragSession");
						var oDraggedRowObjectPath = oDragSession.getDragControl().getBindingContext("products").getPath();
						var oDraggedRowContext = oDragSession.getDragControl().getBindingContext("products").getObject(oDraggedRowObjectPath);
						var oPath = oDraggedRowObjectPath.split("/");
						if (!oDraggedRowContext) {
							return;
						}
						var InputJson = this.products1.getData();
						var oldJson = this.oProductsModel.getData();
						oldJson.Products.splice(oPath[2], 1);
						this.oProductsModel.setData(oldJson);
						this.oProductsModel.refresh(true);
						InputJson.Products.push(oDraggedRowContext);
						this.products1.setData(InputJson);

					},

					moveToTable2: function() {
						this.getSelectedRowContext("table1", function(oSelectedRowContext) {

							var oTable2 = this.products1.getData();
							var RowData1 = {
								Products: []
							};

							var path = oSelectedRowContext.getPath().split("/");
							var oldJson = this.oProductsModel.getData();
		
							var RowData = this.oProductsModel.getData().Products[path[2]];
						
							oTable2.Products[oTable2.Products.length]=RowData;
							for (var i = 0; i < oTable2.Products.length; i++) {
								RowData1.Products.push(oTable2.Products[i]);
							}
												oldJson.Products.splice(path[2], 1);
							this.oProductsModel.setData(oldJson);
							this.oProductsModel.refresh(true);
							this.products1.setData(oTable2);
							this.products1.refresh(true);
						});
					},

					moveSelectedRow: function(sDirection) {
						this.getSelectedRowContext("table2", function(oSelectedRowContext, iSelectedRowIndex, oTable2) {
							var PreviousRow;
									var iSiblingRowIndex = iSelectedRowIndex + (sDirection === "Up" ? -1 : 1);
									var Datajson = {
										Products: []
									};

									var modelData = this.products1.getData();
									
									if(sDirection=="Up"){
										if(iSelectedRowIndex==0){
											Datajson.Products=modelData.Products;
										MessageToast.show("action cannot be performed");
									}else{
									for (var i = 0; i < modelData.Products.length; i++) {
										if (i===iSelectedRowIndex) {
											var temp=modelData.Products[i-1];
											Datajson.Products[i - 1] = modelData.Products[i];
											Datajson.Products[i] = temp;

										} else {
											 PreviousRow = modelData.Products[i];
											Datajson.Products.push(modelData.Products[i]);
										}}}}else{
											if(iSelectedRowIndex==modelData.Products.length-1){
											Datajson.Products=modelData.Products;
										MessageToast.show("action cannot be performed");
									}else{
												for (var i = 0; i < modelData.Products.length; i++) {
										if (i===iSelectedRowIndex) {
											
											var temp1=modelData.Products[i+1];
											Datajson.Products[i + 1] = modelData.Products[i];
											Datajson.Products[i] = temp1;
											i++;

										} else {
											 PreviousRow = modelData.Products[i];
											Datajson.Products.push(modelData.Products[i]);
										}}
											
										}}
										this.products1.setData(Datajson);
										this.products1.refresh(true);

										// after move select the sibling
										oTable2.setSelectedIndex(iSiblingRowIndex);
									});
							},

							moveUp: function() {
								this.moveSelectedRow("Up");
							},

							moveDown: function() {
								this.moveSelectedRow("Down");
							}
					});

			});