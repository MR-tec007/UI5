sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/MessageBox",
	'sap/m/MessageToast'


], function(Controller, JSONModel, formatter, MessageBox,MessageToast) {
	"use strict";
	var arrayData = [];
	return Controller.extend("form.controller.Notification", {
		formatter: formatter,

		onInit: function() {
			this.oModel = new JSONModel();
			this.getView().setModel(this.oModel, "Omodel");
			 this.sampleModel = new JSONModel();
this.getView().setModel(this.sampleModel,"sampleModel");
 this.fragModel = new JSONModel();
this.getView().setModel(this.fragModel,"fragModel");
			var that = this;
var oModel = new JSONModel();
that.getView().setModel(oModel);
//this.arraypress();
var columnModel = new JSONModel();
that.getView().setModel(columnModel);
			this.onIn();
			var array = [{
				Id: "001",
				qty: 1
			}, {
				Id: "002",
				qty: 2
			}, {
				Id: "001",
				qty: 2
			}, {
				Id: "003",
				qty: 4
			}];
		},
		  oNClose: function () {
		  	
		  },
		  
     
                                   typeCsv: function (oEvent) {
var that = this;
var oFileUploader = that.getView().byId("idfileUploader");
var oFile = oFileUploader.getFocusDomRef().files[0];
if (oFile && window.FileReader) {
var reader = new FileReader();
reader.onload = function (evt) {
var strData = evt.target.result; 
that.csvJSON(strData);

};
reader.readAsText(oFile);

			}

		},
csvJSON: function (csv) {
	var oData2={
		result : []
	};
var that = this;
var lines = csv.split("\r\n");
var colheaders = lines[0].split(",");
for (var i = 1; i < lines.length-1; i++) {
var obj = {};
var currentline = lines[i].split(",");
for (var j = 0; j < colheaders.length; j++) {
obj[colheaders[j]] = currentline[j];
				}
oData2.result.push(obj);

			}


	that.sampleModel.setData(oData2);
	var oTable = that.getView().byId("idTable");
	    oTable.setModel(that.sampleModel);
		},
			not: function(oEvent) {
		 var oItem= this.getView().byId("idTable").getSelectedItem();
		 if(oItem!=null){
    var oEntry = oItem.getBindingContext("sampleModel").getObject();
    MessageBox.show("Name of the Product: "+oEntry.Product +" Quantity: "+ oEntry.Price);
		 	
		 }else{
		 	 MessageBox.show("Please select the row");
		 }
		},
	

 createNode:function(text, ref, nodes) {
  return {
    text: text,
    ref: ref,
    nodes: nodes || []
  };
},

 createNestedArray:function(data) {
  var nestedArray = [];

  data.forEach(function(item) {
    var text = item.text;
    var ref = item.ref;
    var nodes = item.nodes;
    var newNode =this.createNode(text, ref, this.createNestedArray(nodes));
    nestedArray.push(newNode);
  });

  return nestedArray;
},
arraypress:function(){
var jsonData = [
  {
    text: "Node1",
    ref: "sap-icon://attachment-audio",
    nodes: [
      {
        text: "Node1-1",
        ref: "sap-icon://attachment-e-pub",
        nodes: [
          {
            text: "Node1-1-1",
            ref: "sap-icon://attachment-html"
          },
          {
            text: "Node1-1-2",
            ref: "sap-icon://attachment-photo"
          }
        ]
      },
      {
        text: "Node1-2",
        ref: "sap-icon://attachment-e-pub",
        nodes: [
          {
            text: "Node1-2-1",
            ref: "sap-icon://attachment-html"
          },
          {
            text: "Node1-2-2",
            ref: "sap-icon://attachment-photo"
          }
        ]
      }
    ]
  },
  {
    text: "Node2",
    ref: "sap-icon://customer-financial-fact-sheet",
    nodes: [
      {
        text: "Node2-1",
        ref: "sap-icon://attachment-html"
      },
      {
        text: "Node2-2",
        ref: "sap-icon://attachment-html"
      }
    ]
  }
];

arrayData = this.createNestedArray(jsonData);
console.log(arrayData);
},
		Editpress:function(oEvent){
		
var oData = {
					"ID":"",
					"Product": "",
					"Quantity": "",
					"Name": "",
					"Price": ""
				};
			 var oItem= this.getView().byId("idTable").getSelectedItem();
		 if(oItem!=null){
		 	 var oEntry = oItem.getBindingContext("sampleModel").getObject();
		 	 oData=oEntry;
		 	
		 	 	this.fragModel.setData(oEntry);
		 	if(!this.Dbox){
                     this.Dbox = sap.ui.xmlfragment("Notificaton.view.edit",this);
                     this.getView().addDependent(this.Dbox);
                       }
                       this.Dbox.open();
                       
                 }
		 	
		 else{
		 	 MessageBox.show("Please select the row");
		 }
		},
			Addpress:function(oEvent){
				
			
		 	
		 	if(!this.Dbox1){
                     this.Dbox1 = sap.ui.xmlfragment("Notificaton.view.AddRow",this);
                     this.getView().addDependent(this.Dbox1);
                       }
                       this.Dbox1.open();
                      
                      
                 
		},
				Addpress1:function(oEvent){
						if(!this.oFragment){
                     this.oFragment = sap.ui.xmlfragment("Notificaton.view.AddRow",this);
                     this.getView().addDependent(this.oFragment);
                       }
			

		this.getView().addDependent(this.oFragment); 
		 	this.oFragment.open();
		 	// if(!this.Dbox2){
    //                  this.Dbox1 = sap.ui.xmlfragment("Notificaton.view.edit",this);
    //                  this.getView().addDependent(this.Dbox2);
    //                   }
    //                   this.Dbox2.open();
                      
                      
                 
		},
			onClose : function(){
            	this.Dbox1.close();
    	   	},
		oneditRow: function(oEvent){
			var oData = {
					"ID":"",
					"Product": "",
					"Quantity": "",
					"Name": "",
					"Price": ""
				};
				var OrgData= this.sampleModel.getData();
				 	var addData= this.fragModel.getData();
				
				OrgData.result.push.apply(addData);
				this.sampleModel.setData(OrgData);
	var oTable = this.getView().byId("idTable");
	    oTable.setModel(this.sampleModel);
				 MessageToast.show("Row edited");
				 	this.Dbox.close();
				 		this.fragModel.setData(oData);
		},
		onAddRow: function(oEvent){
			var oData = {
					"ID":"",
					"Product": "",
					"Quantity": "",
					"Name": "",
					"Price": ""
				};
				var OrgData= this.sampleModel.getData();
				 	var addData= this.fragModel.getData();
				
				OrgData.result.push(addData);
				this.sampleModel.setData(OrgData);
	var oTable = this.getView().byId("idTable");
	    oTable.setModel(this .sampleModel);
				 MessageToast.show("Row Added");
				 	this.Dbox1.close();
				 		this.fragModel.setData(oData);
		},
		onCancel :function(){
					
var oData = {
					"ID":"",
					"Product": "",
					"Quantity": "",
					"Name": "",
					"Price": ""
				};
				this.fragModel.setData(oData);
				this.Dbox.close();
			
		},
			onCancela :function(){
					
var oData = {
					"ID":"",
					"Product": "",
					"Quantity": "",
					"Name": "",
					"Price": ""
				};
				this.fragModel.setData(oData);
			
				this.Dbox1.close();
		},
		onCloseDialog : function(){
            	this.Dbox.close();
    	   	},
	/*	Function to create the table dynamically for csv File*/

		onIn: function() {
			var oData = {
				"NotificationGroups": [{
					"title": "New order",
					"description": "Aliquam quis varius ligula. In justo lorem, lacinia ac ex at, vulputate dictum turpis.",
					"priority": "High",
					"unread": true,
						"number":"1",
					"authorName": "Michael Muller",
					"authorPicture": "sap-icon://person-placeholder",
					"authorAvatarColor": "Accent2",
					"qty": "2",
					"aa": "---"
				}, {
					"title": "New order",
					"description": "Lacinia ac ex at, vulputate dictum turpis.",
					"priority": "Low",
						"number":"2",
					"authorInitials": "JS",
					"unread": true,
					"qty": "1",
					"aa": ""

				}, {
					"title": "New",
					"description": "Lacinia ac ex at, vulputate dictum turpis.",
					"priority": "Low",
						"number":"3",
					"authorInitials": "JS",
					"unread": true,
					"aa": ""

				}, {
					"title": "New order (#2527)",
					"creationDate": "1 hour ago",
					"priority": "Medium",
					"number":"4",
					"showEmptyGroup": true,
					"showCloseButton": true,
					"aa": "---"
				}]
			};

			var array = [{
				Id: "001",
				qty: 1
			}, {
				Id: "002",
				qty: 2
			}, {
				Id: "001",
				qty: 2
			}, {
				Id: "003",
				qty: 4
			}];
			// var cars = [{ make: 'audi', model: 'r8', year: '2012' }, { make: 'audi', model: 'rs5', year: '2013' }, { make: 'ford', model: 'mustang', year: '2012' }, { make: 'ford', model: 'fusion', year: '2015' }, { make: 'kia', model: 'optima', year: '2012' }],
			//     result = oData.NotificationGroups.reduce(function (r, a) {
			//         r[a.title] = r[a.title] || [];
			//         r[a.title].push(a.groupItems);
			//         return r;
			//     }, Object.create(null));

			var result;
			var data = {
				result: []
			};
			var data1={
				result1:[]
			};
			var array1 = [
				["apple", "banana"],
				[],
				[],
				[],
				["kiwi"],
				[],
				[]
			]; // sample array

			var result1 = array1.filter(function(e) {
				return e.length;
			});
			console.log(result1);

			oData.NotificationGroups.reduce(function(res, value) {
				if (!res[value.title]) {
					res[value.title] = {
						title: value.title,
						groupItems: []
					};
					
					data.result.push(res[value.title]);
				}
				for (var i = 0; i < 1; i++) {
					if (!res[value.title].groupItems[i]) {
						res[value.title].groupItems[i] = value;
					
					}
					else {
						for (var j = 1; j < 2; j++) {
							data.result.push.apply(res[value.title].groupItems[j] = value);
						

						}
					}
				}
				return res;
			}, {});
			
			data.result.reduce(function(res, value) {
				if (!res[value.title]) {
					res[value.title] = {
						title: value.title,
						groupItems: []
					};
					
					data1.result1.push(res[value.title]);
				}
				for (var i = 0; i < 1; i++) {
					if (!res[value.title].groupItems[i]) {
						res[value.title].groupItems[i] = value;
					
					}
					else {
						for (var j = 1; j < 2; j++) {
							data1.result1.push.apply(res[value.title].groupItems[j] = value);

						}
					}
				}
				return res;
			}, {});
			this.oModel.setData(data1);

		},
	
		not1: function() {
			var array12 = {
				"NotificationGroups": [{
					"title": "New order",
					"description": "Aliquam quis varius ligula. In justo lorem, lacinia ac ex at, vulputate dictum turpis.",
					"number":"1",
					"priority": "High",
					"unread": true,
					"authorName": "Michael Muller",
					"authorPicture": "sap-icon://person-placeholder",
					"authorAvatarColor": "Accent2",
					"qty": "2"
				}, {
					"title": "New order",
					"description": "Lacinia ac ex at, vulputate dictum turpis.",
					"number":"2",
					"priority": "Low",
					"authorPicture": "sap-icon://person-placeholder",
					"authorInitials": "JS",
					"unread": true,
					"qty": "1"

				}, {
					"title": "New",
					"description": "Lacinia ac ex at, vulputate dictum turpis.",
					"authorPicture": "sap-icon://person-placeholder",
					"priority": "Low",
					"number":"3",
					"authorInitials": "JS",
					"unread": true

				}, {
					"title": "New order (#2527)",
					"description": "Teat  ac ex at, vulputate dictum turpis.",
					"creationDate": "1 hour ago",
					"number":"4",
					"priority": "Medium",
					"authorPicture": "sap-icon://person-placeholder",
					"showEmptyGroup": true,
					"showCloseButton": true
				}]
			};
			this.oModel.setData(array12);
		},
		onAcceptPress: function(oEvent) {
			var oItem = oEvent.getSource().getBindingContext("Omodel").getPath();
			// var model = this.getModel().getProperty(oItem);
			var item=oEvent.getSource().getBindingContext("Omodel").getProperty(oItem);
		
			MessageBox.show("title:"+item.title+"identifier"+ item.number);
			if(!this.Dbox2){
                     this.Dbox2 = sap.ui.xmlfragment("Notificaton.view.edit",this);
                     this.getView().addDependent(this.Dbox2);
                       }
                       this.Dbox2.open();

		},
		notificationType: function() {
			var that = this;
			var oSelf = this;
			var Data;
			var ErrType = new JSONModel();
			var param = [{
				name: 'QueryTemplate',
				value: 'SAPMEDataValidation/WorkInstruction/Query/WorkInstruction_Xry'

			}, {
				name: 'content-type',
				value: 'text/json'
			}, {
				name: 'Param.1',
				value: plant
			}];
			$.ajax({
				type: "POST",
				url: "/XMII/Illuminator",
				dataType: "json",
				data: param,
				async: true,
				success: function(data) {

					var row = data.Rowsets.Rowset[0].Row;

					if (row) {
						Data = {
							List: []
						};
						Data.List = row;
						ErrType.setData(Data);

					} else {
						Data = {
							List: []
						};
						ErrType.setData(Data);

					}

					ErrType.setData(Data);
					oSelf.getView().setModel(ErrType, "ErrType");
					var data1 = {
						result: []
					};
					var groupItems = groupItems.filter(function() {
						return true;
					});
					Data.List.reduce(function(res, value) {
						if (!res[value.ErrorMessage]) {
							res[value.ErrorMessage] = {
								ErrorMessage: value.ErrorMessage,
								groupItems: []
							};
							data1.result.push(res[value.ErrorMessage]);

						}
						for (var i = 0; i < 1; i++) {
							if (!res[value.ErrorMessage].groupItems[i]) {
								res[value.ErrorMessage].groupItems[i] = value;
							} else {
								for (var j = 1; j < 2; j++) {
									data1.result.push.apply(res[value.ErrorMessage].groupItems[j] = value);
								}
							}
						}

						return res;
					}, {});
				}
			});
		}

	});
});