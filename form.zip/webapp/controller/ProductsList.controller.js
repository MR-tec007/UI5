sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (Controller, JSONModel, Filter, FilterOperator,MessageToast) {
	"use strict";

	return Controller.extend("form.controller.ProductsList", {


		onInit: function () {
			var oData={
  "Invoices": [
	{
	  "ProductName": "apple",
	  "Quantity": 21,
	  "ExtendedPrice": 87.2,
	  "ShipperName": "Fun Inc.",
	  "ShippedDate": "2015-04-01T00:00:00",
	  "Status": "A"
	},
	{
	  "ProductName": "Milk",
	  "Quantity": 4,
	  "ExtendedPrice": 10,
	  "ShipperName": "ACME",
	  "ShippedDate": "2015-02-18T00:00:00",
	  "Status": "B"
	},
	{
	  "ProductName": "Honey",
	  "Quantity": 3,
	  "ExtendedPrice": 6.85,
	  "ShipperName": "ACME",
	  "ShippedDate": "2015-03-02T00:00:00",
	  "Status": "B"
	},
	{
	  "ProductName": "veggies",
	  "Quantity": 2,
	  "ExtendedPrice": 68.8,
	  "ShipperName": "ACME",
	  "ShippedDate": "2015-04-12T00:00:00",
	  "Status": "C"
	},
	{
	  "ProductName": "Wheat bread",
	  "Quantity": 1,
	  "ExtendedPrice": 2.71,
	  "ShipperName": "Fun Inc.",
	  "ShippedDate": "2015-01-27T00:00:00",
	  "Status": "A"
	}
  ]
};
			this.omdel= new sap.ui.model.json.JSONModel(oData);
			this.getView().setModel(this.omdel,"omdel");
			var oViewModel = new JSONModel({
				currency: "EUR"
			});
			this.getView().setModel(oViewModel, "view");
			var sPath = jQuery.sap.getResourcePath("form/webapp/persons.json");
			var oModel = new JSONModel(sPath);
			this.getView().setModel(oModel);
		
		},
		onAfterRendering:function(){
			this.replaceTextWithButtons();
			 var oTable1 = this.byId("inputTable");
				for (var i = 0; i < 5; i++) {
	var oColumn = new sap.m.Column("col" + i, {
		width: "1em",
		header: new sap.m.Label({
		text:" <oData header text binding>"
		})
	});
  oTable1.addColumn(oColumn);
  var oCell = [];
  var col="Param";
for ( var j = 0; j < 5; j++) {
                if (i === 0) {
                var cell1 = new sap.m.Text({
                                text: col+j
                                });
                }
oCell.push(cell1);
}
var aColList = new sap.m.ColumnListItem("aColList", {
         cells: oCell
      });
      oTable1.bindItems("<entityset>", aColList);
}
		},
	
     replaceTextWithButtons: function() {
   
      var oTable = this.byId("inputTable");
      var iItemCount = oTable.getItems().length;
      for (var i = 0; i < iItemCount; i++) {
        var oItem = oTable.getItems()[i];
        var colLength=oItem.getCells().length;
       
        // var sText = oCell.getText();
        var oButton = new sap.m.Button({
          text: "sText",
          press:function(oEvent){
			var sObjects=oEvent.getParameters();
}
        });
        for(var j=colLength-1;j>3;j--){
        	 var oCell = oItem.getCells()[j];
        	 if(oCell){
       oCell.destroy();
       colLength--;
        	 }
        }
        oItem.addCell(oButton);
      }
    },
onButtonPress:function(){
	alert("sss");
},




		onFilterInvoices : function (oEvent) {

			// build filter array
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Name", FilterOperator.Contains, sQuery));
			}

			// filter binding
			var oList = this.byId("productsList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},
			onPress: function (oEvent) {
				var oItem = oEvent.getSource();
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Detail", {
				productsPath: window.encodeURIComponent(oItem.getBindingContext("products").getPath().substr(1))
			});
		},
		press : function(evt) {
			MessageToast.show("The GenericTile is pressed.");
		},
			onPressT: function (oEvent) {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("ProductsList");
			}
		
	});

});