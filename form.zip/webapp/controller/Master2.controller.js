sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("form.controller.Master2", {
		onInit: function() {

			this.oNavigatingModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this.oNavigatingModel, "oNavigatingModel");
			var data = {
				"nodes1": [{
					"text": "Node1",
					"ref": "sap-icon://create",
					"nodes": [{
						"text": "Overview",
						"id": "Overview",
						"ref": "sap-icon://attachment-e-pub",
					}, {
						"text": "Master",
						"id": "Master",
						"ref": "sap-icon://create"
					}, {
						"text": "VizFrame",
						"id": "VizFrame",
						"ref": "sap-icon://create"
					}, {
						"text": "InvoiceList",
						"id": "InvoiceList",
						"ref": "sap-icon://create"
					}]
				}, {
					"text": "Node2",
					"ref": "sap-icon://attachment-audio",
					"nodes": [{
						"text": "ProductsList",
						"id": "ProductsList",
						"ref": "sap-icon://attachment-e-pub"
					}, {
						"text": "Notification",
						"id": "Notification",
						"ref": "sap-icon://attachment-e-pub"
					}]

				}, {
					"text": "Node3",
					"ref": "sap-icon://attachment-e-pub",
					"nodes": [{
						"text": "TableCellSelect",
						"id": "TableCellSelect",
						"ref": "sap-icon://attachment-e-pub"
					}, {
						"text": "DragAndDrop",
						"id": "DragAndDrop",
						"ref": "sap-icon://attachment-e-pub"
					}, {
						"text": "Cards",
						"id": "Cards",
						"ref": "sap-icon://attachment-e-pub"
					}]

				}, {
					"text": "Node4-SQL",
					"ref": "sap-icon://attachment-e-pub",
					"nodes": [{
						"text": "OrderStatus",
						"id": "OrderStatus",
						"ref": "sap-icon://attachment-e-pub"
					},{
						"text": "Gantt",
						"id": "Gantt",
						"ref": "sap-icon://attachment-e-pub"
					}]

				}]
			};
			this.oNavigatingModel.setData(data);
		},

		onItemSelect: function(oEvent) {
			var oItem = oEvent.getParameter("item");
			// 	var oItemPath=oEvent.getSource().getBindingContext("oNavigatingModel").getPath();
			// var oItemObject=oEvent.getSource().getBindingContext("oNavigatingModel").getObject(oItemPath);
			// var router_Id=oItemObject.id;
			var oRouter = this.getOwnerComponent().getRouter();

			oRouter.navTo(oItem.getText());
		},
		oNavigationpage: function(oEvent) {
			var oItemPath = oEvent.getSource().getBindingContext("oNavigatingModel").getPath();
			var oItemObject = oEvent.getSource().getBindingContext("oNavigatingModel").getObject(oItemPath);
			var router_Id = oItemObject.id;
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo(router_Id);
		},
		onCollapseExpandPress: function() {
			var oNavigationList = this.byId("sideNavigation");
			var bExpanded = oNavigationList.getExpanded();

			oNavigationList.setExpanded(!bExpanded);
		},

		onHideShowSubItemPress: function() {
			var oNavListItem = this.byId("subItemThree");
			oNavListItem.setVisible(!oNavListItem.getVisible());
		},
		SelectedKey: function() {
			alert('4233');
		}

	});
});