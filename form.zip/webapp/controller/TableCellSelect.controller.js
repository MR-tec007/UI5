sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	
	var selectedCellList = [];


	return Controller.extend("form.controller.TableCellSelect", {
		onInit: function() {

			var oThat;
			var oTable = this.getView().byId("InvoiceTableID");
			oTable.onAfterRendering = function() {
				if (sap.m.Table.prototype.onAfterRendering) {
					sap.m.Table.prototype.onAfterRendering.apply(this);
				}
				var tbl = this;
				tbl.lastSelectedCell = null;
				var items = this.getItems();
				for (var i = 0; i < items.length; i++) {
					var item = items[i];
					var path = "invoices>/Invoices";
					var cells = item.getAggregation('cells');

					for (var j = 0; j < cells.length; j++) {
						var clicks = 0;
						var cell = cells[j];
						var $cell = cell.$();
						$cell.attr('path', path);
						$cell.attr('bindName', cell.mBindingInfos.text.parts[0].path);
						var $parent = $cell.parent();		
						$parent.css('cursor', 'pointer');

						$parent.click(function() { 
							clicks++;
							var oThis = this;
							var $oThis = $(this);
							var cellId = $oThis[0].id;
							var initialColor=	$oThis.css('background-color');
								if($oThis.css("background-color") === "rgb(146, 183, 254)"){
									$oThis.css('background-color', 'rgba(0, 0, 0, 0)');
								}else{
										$oThis.css('background-color', 'rgb(146, 183, 254)');
									selectedCellList.push(cellId);
								}
							});
					}
				}
			};
		},
	

	});
});