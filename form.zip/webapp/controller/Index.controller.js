sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/m/MessageBox"
], function (Controller,MessageToast,JSONModel,ResourceModel,MessageBox) {	"use strict";

	return Controller.extend("form.controller.Index", {

		onInit:function(){
			var oData={
				recipient:{
					name:""
				}
			};
			var oModel = new JSONModel(oData);
			this.getView().setModel(oModel);
		var i18nModel = new ResourceModel({
				bundleName: "form.i18n.i18n"
			});
			this.getView().setModel(i18nModel, "i18n");
		},
		press : function(evt) {
			MessageToast.show("The GenericTile is pressed.");
		},


		onSubmit : function () {
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
		    	var sRecipient = this.getView().getModel().getProperty("/recipient/name");
			    var sMsg = oBundle.getText("helloMsg", [sRecipient]);
			/* eslint-enable no-alert */
			MessageToast.show(sMsg);
		},onConfirmationMessageBoxPress: function () {
			MessageBox.confirm("Approve purchase order for NoteBook 19");
		},

		onAlertMessageBoxPress: function () {
			MessageBox.alert("The product you have choosed is less in stocks.");
		},

		onErrorMessageBoxPress: function () {
			MessageBox.error("The  \"product\" is \n\"Out of Stock\" pick other products.");
		},

		onInfoMessageBoxPress: function () {
			MessageBox.information("Your booking will be reserved for 24 hours.");
		},
		onSuccessMessageBoxPress:function () {
			MessageBox.success("Your booking done Successfully.");
		},
		onWarningMessageBoxPress:function () {
			MessageBox.warning("Do you want to cancel the order.");
		}
		
	});

});