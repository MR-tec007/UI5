sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller,JSONModel,MessageBox) {
	"use strict";
var that;
	return Controller.extend("check.controller.View1", {
			onInit: function() {
				that=this;
			
					var oDate={
		"SDate":"",
		"EDate":""
	};
	
				var oData1={
				"ID":"",
				"NAME":"",
				"BRAND":"",
				"MADEIN":"",
				"PRICE":""
				};
		var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd-MM-yyyy"
			});
			var ar=4;
		var date = new Date();
		oDate.EDate=oDateFormat.format(date);
		var Sdate=new Date(date.setDate(date.getDate()-5));
		oDate.SDate=oDateFormat.format(Sdate);
		date.setHours(date.getHours()-ar);
		var endtamp = oDateFormat.format(date);			
		 var multiComboBox = this.getView().byId("multiComboBox");
		 this.DataModel=new sap.ui.model.json.JSONModel();
		 this.getView().setModel(this.DataModel,"DataModel");
		 this.FragModel=new sap.ui.model.json.JSONModel();
		 this.getView().setModel(this.FragModel,"FragModel");
		 	 this.MaterialModel=new sap.ui.model.json.JSONModel();
		 this.getView().setModel(this.MaterialModel,"MaterialModel");
		  this.inputModel=new sap.ui.model.json.JSONModel();
		 this.getView().setModel(this.inputModel,"inputModel");
		this.inputModel.setData(oDate);
		 this.InsertModel=new sap.ui.model.json.JSONModel();
		 this.InsertModel.setData(oData1);
		 this.getView().setModel(this.InsertModel,"InsertModel");
    
			 this.updateClock();
			 this.fn_call();
			 this.fn_callMaterial();

            // Schedule updateClock to be called every second
            setInterval(this.updateClock.bind(this), 1000);
},


        updateClock: function () {
            var now = new Date();
             var year = now.getFullYear();
			 var month = now.getMonth() + 1; // Months are zero-indexed
    		var day = now.getDate();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var seconds = now.getSeconds();
			 var dateString = this.formatTime(day) + "/" + this.formatTime(month) + "/" + year;
  
            var timeString = this.formatTime(hours) + ":" + this.formatTime(minutes) + ":" + this.formatTime(seconds);

            // Update the text control with the current time
            this.getView().byId("clockText").setText( dateString+" ---" + timeString);
        },

        formatTime: function (time) {
            return (time < 10 ? "0" : "") + time;
        },
onOpenDialogBox:function(){

	var Temp={
		"Production_Order":"",
		"Material":"",
		"Ord_Quantity":"",
		"Ord_Description":"",
		"Ord_Status":"",
		"Start_Date":"",
		"End_Date":""};
	that.FragModel.setData(Temp);
	
	if(!this.Dbox){
                     this.Dbox = sap.ui.xmlfragment("form.view.AddRow",this);
                     this.getView().addDependent(this.Dbox);
                       }
                       this.Dbox.open();
                 },
                 
        	onCloseDialog : function(){
        			var test={
				"ID":"",
				"NAME":"",
				"BRAND":"",
				"MADEIN":"",
				"PRICE":""
				};
				that.InsertModel.setData(test);
            	this.Dbox.close();
    	   	},
onAddRow:function(){
	var DataJson=that.FragModel.getData();
	var quantity=parseInt(DataJson.Ord_Quantity);
	DataJson.quantiy=quantity;
	 $.ajax({
        url: 'http://localhost:3000/dataMaterialInsertRow', 
        type: 'GET',
        data:DataJson,
        dataType: 'json',
        success: function(data) {
        MessageBox.success("One Row Instered Successfully");
        },
        error: function(xhr, status, error) {
        	 MessageBox.error("Error occurred ");
          console.error('Error occurred:', status, error);
        }
      });
	
},
fn_call:function(){
	var Date={
		"SDate":"",
		"EDate":""
	};
	var iDate=that.inputModel.getData();
	var oMaterial= that.getView().byId("mComboBox").getSelectedKey();

		iDate.oMaterial=oMaterial;
 $.ajax({
        url: 'http://localhost:3000/getOrderData', 
        type: 'GET',
        data:iDate,
        dataType: 'json',
        success: function(data) {
          var Json={
          	Data:[]
          };
          Json.Data=data;
          that.DataModel.setData(Json);
        },
        error: function(xhr, status, error) {
          console.error('Error occurred:', status, error);
        }
      });
},
fn_callMaterial:function(){

 $.ajax({
        url: 'http://localhost:3000/getOrderDataMaterial', 
        type: 'GET',
        dataType: 'json',
        success: function(data) {
          var MaterialJson={
          MaterialData:[]
          };
          MaterialJson.MaterialData=data;
          that.MaterialModel.setData(MaterialJson);
        },
        error: function(xhr, status, error) {
          console.error('Error occurred:', status, error);
        }
      });
}
	});
});