sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/m/MessageToast",
	"sap/ui/Device"
], function(Controller,MessageToast,Device) {
	"use strict";

	return Controller.extend("form.controller.Master", {
			onInit: function () {
			this.getSplitAppObj().setHomeIcon({
				'phone': 'phone-icon.png',
				'tablet': 'tablet-icon.png',
				'icon': 'desktop.ico'
			});

			Device.orientation.attachHandler(this.onOrientationChange, this);
		},
				onExit: function () {
			Device.orientation.detachHandler(this.onOrientationChange, this);
		},

		onOrientationChange: function (mParams) {
			var sMsg = "Orientation now is: " + (mParams.landscape ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, { duration: 5000 });
		},

		onPressNavToDetail: function () {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack: function () {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack: function () {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster: function () {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},
			onPressGoToGrid: function () {
			this.getSplitAppObj().to(this.createId("Grid"));
		},
			onPressGoToIndex: function () {
			this.getSplitAppObj().to(this.createId("Form"));
		},
			onPressGoToVizframe: function () {
			this.getSplitAppObj().to(this.createId("VizFrame"));
		},onPressGoToNotification:function(){
			this.getSplitAppObj().to(this.createId("Notification"));
		},onPressGoToCards:function(){
			this.getSplitAppObj().to(this.createId("Cards"));
		},onPressGoTocards1:function(){
			this.getSplitAppObj().to(this.createId("cards1"));
		},onPressGoToSort:function(){
			this.getSplitAppObj().to(this.createId("Sort"));
		},onPressGoToTableCellSelect:function(){
			this.getSplitAppObj().to(this.createId("TableCellSelect"));
		},onPressGoToDragAndDrop:function(){
			this.getSplitAppObj().to(this.createId("DragAndDrop"));
		},onPressGoToMaster2:function(){
			this.getSplitAppObj().to(this.createId("Master2"));
		},


		onListItemPress: function (oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn: function (oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, { duration: 5000 });
		},

		getSplitAppObj: function () {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				Log.info("SplitApp object can't be found");
			}
			return result;
		}

	});
});