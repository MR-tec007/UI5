sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"

], function (Controller,JSONModel,MessageBox) {
	"use strict";
var arrrayToSorted=[];
var sortedArray=[];

	return Controller.extend("form.controller.Sort", {

		onInit: function () {
			this.InputModel = new JSONModel();
			this.getView().setModel(this.InputModel,"InputModel");
				this.arrrayToSortedModel = new JSONModel();
			this.getView().setModel(this.arrrayToSortedModel,"arrrayToSortedModel");
		},
		changeArray:function(){
			var arrayCount=this.getView().byId("idArrayCount").getValue();
			var InputJson={InputArray:[]};
			if(arrayCount>2){  
			
				for(var i=0;i<arrayCount;i++){
					InputJson.InputArray.push({
					IdCount:i+1,
					Values:"",
					state:"None"
				});
				}
				this.InputModel.setData(InputJson);
			}else{
				MessageBox.show("enter values greater than 3");
			}
		},onCheckArray:function(){
			arrrayToSorted=[];
				var arrayCount=this.getView().byId("idArrayCount").getValue();
				var RowData=" ";
				if(arrayCount>2){
					var CheckJson=this.InputModel.getData();
						for(var i=0;i<CheckJson.InputArray.length;i++){
							if(CheckJson.InputArray[i].Values!=""||CheckJson.InputArray[i].Values!=undefined){
								arrrayToSorted.push(parseInt(CheckJson.InputArray[i].Values));
							}
						}
							for(var i=0;i<arrrayToSorted.length;i++){
					 RowData=RowData+"  ,"+arrrayToSorted[i];
							}
								MessageBox.show("enterted array values are:"+RowData);
				}else if(arrayCount==undefined){
						MessageBox.show("enter array count value");
				}else{
						MessageBox.show("enter values greater than 3");
				}
		},
		// Sort:function(){
		// 	var arraySort=[];
		// var array=arrrayToSorted;
		// for(var j=0;j<array.length;j++){
		// 	for(var k=0;k<arrrayToSorted.length;k++){
		// 	if(array[j]>arrrayToSorted[k]){
		// 		arraySort.push(arrrayToSorted[k]);
		// 	}}
		// }
		// 	var RowData1=" ";
		// 	for(var i=0;i<arraySort.length;i++){
		// 			 RowData1=RowData1+"  ,"+arraySort[i];
		// 					}
		// 						MessageBox.show("Sorted array values are:"+RowData1);
		
		// },
	Sort:function() {
			var array=arrrayToSorted;
  var done = false;
  while (!done) {
    done = true;
    for (var i = 1; i < array.length; i++) {
      if (array[i - 1] > array[i]) {
        done = false;
        var tmp = array[i - 1];
        array[i - 1] = array[i];
        array[i] = tmp;
      }
    }
  }


  	var RowData1=" ";
			for(var j=0;j<array.length;j++){
					 RowData1=RowData1+"  ,"+array[j];
							}
								MessageBox.show("Sorted array values are:"+RowData1);
}

	
	});
});