sap.ui.define(['sap/m/MessageToast', 'sap/ui/core/mvc/Controller',"sap/ui/model/json/JSONModel"],
	function (MessageToast, Controller,JSONModel){
	"use strict";

	return Controller.extend("form.controller.Cards", {

		onInit: function () {
				var sampleDatajson = new sap.ui.model.json.JSONModel("Data.json");
			var oVizFrame = this.getView().byId("idVizFrame");
				oVizFrame.setModel(sampleDatajson);
					var oVizFrame1 = this.getView().byId("idVizFrame1");
				oVizFrame1.setModel(sampleDatajson);
			
		},
		onBookPress: function() {
			MessageToast.show("By pressing the 'Book' button a new application can be opened where the actual booking happens. This can be in the same window, in a new tab or in a dialog.");
		}

	});

	 

});